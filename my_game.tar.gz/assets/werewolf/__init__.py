"""Werewolf game package."""
